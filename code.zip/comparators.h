#ifndef COMPARATORS_H
#define COMPARATORS_H

#include "numbers.h" 

int uint8_bits8_comparator(void* expected, void* got);
int uint8_uint8_comparator(void* expected, void* got);

#endif